@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.swipegallery

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlin.math.abs

data class Media(val uri: Uri, val isVideo: Boolean, val date: Long)

class MainActivity : ComponentActivity() {
    private var hasAccess by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(
            if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                if (hasAccess) Gallery(this)
                else Column(
                    Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ডিলিটের সময় বারবার অনুমতি না চাইতে \"All files access\" চালু করুন", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:$packageName")))
                    }) { Text("অনুমতি দিন") }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasAccess = Environment.isExternalStorageManager()
    }
}

fun loadMedia(ctx: Context): List<Media> {
    val out = mutableListOf<Media>()
    fun query(base: Uri, video: Boolean) {
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED), null, null, null
        )?.use { c ->
            while (c.moveToNext())
                out += Media(ContentUris.withAppendedId(base, c.getLong(0)), video, c.getLong(1))
        }
    }
    query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
    query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    return out.sortedByDescending { it.date }
}

fun trash(ctx: Context, m: Media): Boolean = try {
    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_TRASHED, 1) }
    ctx.contentResolver.update(m.uri, v, null, null) > 0
} catch (e: Exception) { false }

@Composable
fun Gallery(ctx: Context) {
    val items = remember { mutableStateListOf<Media>().apply { addAll(loadMedia(ctx)) } }
    val pager = rememberPagerState { items.size }
    val scope = rememberCoroutineScope()
    var warned by rememberSaveable { mutableStateOf(false) } // অ্যাপ খোলার পর একবারই সতর্ক করবে
    var pending by remember { mutableStateOf<Media?>(null) }

    fun doTrash(m: Media) {
        if (trash(ctx, m)) items.remove(m)
        else Toast.makeText(ctx, "ট্র্যাশে পাঠানো যায়নি", Toast.LENGTH_SHORT).show()
    }
    fun next() {
        if (pager.currentPage < items.size - 1)
            scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (items.isEmpty()) {
            Text("কোনো ছবি বা ভিডিও নেই", color = Color.White, modifier = Modifier.align(Alignment.Center))
        } else {
            VerticalPager(pager, Modifier.fillMaxSize(), key = { items[it].uri.toString() }) { page ->
                val m = items[page]
                Page(
                    m, isCurrent = pager.currentPage == page,
                    onLeft = { if (warned) doTrash(m) else pending = m },
                    onRight = { next() }
                )
            }
            Text(
                "${pager.currentPage + 1} / ${items.size}", color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
            )
        }
    }

    pending?.let { m ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("সতর্কতা") },
            text = { Text("বামে সোয়াইপ করলে ছবি/ভিডিও রিসাইকেল বিনে চলে যাবে। এরপর আর জিজ্ঞেস করা হবে না।") },
            confirmButton = {
                TextButton(onClick = { warned = true; doTrash(m); pending = null }) { Text("ঠিক আছে, ডিলিট করো") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("বাতিল") } }
        )
    }
}

@Composable
fun Page(m: Media, isCurrent: Boolean, onLeft: () -> Unit, onRight: () -> Unit) {
    var dx by remember { mutableFloatStateOf(0f) }
    var paused by remember { mutableStateOf(false) }
    val left by rememberUpdatedState(onLeft)
    val right by rememberUpdatedState(onRight)

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            translationX = dx
            rotationZ = dx / 40f
            alpha = 1f - (abs(dx) / 1500f).coerceAtMost(0.5f)
        }) {
            if (m.isVideo) {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(m.uri)
                            setOnPreparedListener { it.isLooping = true }
                        }
                    },
                    update = { v -> if (isCurrent && !paused) v.start() else v.pause() },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                AsyncImage(m.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
        // গেসচার লেয়ার: ট্যাপ = ভিডিও পজ/প্লে, বামে সোয়াইপ = ট্র্যাশ, ডানে সোয়াইপ = পরেরটা
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { paused = !paused } }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            val d = dx; dx = 0f
                            if (d < -200f) left() else if (d > 200f) right()
                        },
                        onDragCancel = { dx = 0f }
                    ) { _, delta -> dx += delta }
                }
        )
    }
}
