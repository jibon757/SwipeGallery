@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.swipegallery

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val SWIPE = 90f // বামে/ডানে কতটা টানলে কাজ করবে (কম = বেশি সেনসিটিভ)

data class Media(val uri: Uri, val isVideo: Boolean, val date: Long)

class MainActivity : ComponentActivity() {
    private var hasAccess by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(
            if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                if (hasAccess) Gallery(this)
                else Column(
                    Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("ডিলিটের সময় বারবার অনুমতি না চাইতে \"All files access\" চালু করুন", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:$packageName")))
                    }) { Text("অনুমতি দিন") }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasAccess = Environment.isExternalStorageManager()
    }
}

fun loadMedia(ctx: Context): List<Media> {
    val out = mutableListOf<Media>()
    fun query(base: Uri, video: Boolean) {
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED), null, null, null
        )?.use { c ->
            while (c.moveToNext())
                out += Media(ContentUris.withAppendedId(base, c.getLong(0)), video, c.getLong(1))
        }
    }
    query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
    query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    return out.sortedByDescending { it.date }
}

fun trash(ctx: Context, m: Media): Boolean = try {
    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_TRASHED, 1) }
    ctx.contentResolver.update(m.uri, v, null, null) > 0
} catch (e: Exception) { false }

fun untrash(ctx: Context, m: Media): Boolean = try {
    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_TRASHED, 0) }
    val extras = Bundle().apply { putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_INCLUDE) }
    ctx.contentResolver.update(m.uri, v, extras) > 0
} catch (e: Exception) { false }

@Composable
fun Gallery(ctx: Context) {
    val items = remember { mutableStateListOf<Media>().apply { addAll(loadMedia(ctx)) } }
    val pager = rememberPagerState { items.size }
    val scope = rememberCoroutineScope()
    var warned by rememberSaveable { mutableStateOf(false) } // অ্যাপ খোলার পর একবারই সতর্ক করবে
    var pending by remember { mutableStateOf<Media?>(null) }
    var showJump by remember { mutableStateOf(false) }
    var rapid by remember { mutableIntStateOf(0) } // 0 = বন্ধ, 2 বা 4 = সেকেন্ডে কয়টা
    val undo = remember { ArrayDeque<Pair<Int, Media>>() }

    fun doTrash(m: Media) {
        val idx = items.indexOf(m)
        if (idx >= 0 && trash(ctx, m)) {
            undo.addLast(idx to m)
            items.removeAt(idx)
        } else Toast.makeText(ctx, "ট্র্যাশে পাঠানো যায়নি", Toast.LENGTH_SHORT).show()
    }
    fun undoLast() {
        val (idx, m) = undo.removeLastOrNull() ?: run {
            Toast.makeText(ctx, "আনডু করার মতো কিছু নেই", Toast.LENGTH_SHORT).show()
            return
        }
        if (untrash(ctx, m)) {
            val at = idx.coerceAtMost(items.size)
            items.add(at, m)
            scope.launch { pager.scrollToPage(at) }
        } else {
            undo.addLast(idx to m)
            Toast.makeText(ctx, "আনডু করা যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(rapid) {
        while (rapid > 0) {
            if (pager.currentPage >= items.size - 1) { rapid = 0; break }
            pager.scrollToPage(pager.currentPage + 1)
            delay(1000L / rapid)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (items.isEmpty()) {
            Text("কোনো ছবি বা ভিডিও নেই", color = Color.White, modifier = Modifier.align(Alignment.Center))
        } else {
            VerticalPager(
                pager, Modifier.fillMaxSize(),
                flingBehavior = PagerDefaults.flingBehavior(state = pager, snapPositionalThreshold = 0.15f),
                key = { items[it].uri.toString() }
            ) { page ->
                val m = items[page]
                Page(
                    m, isCurrent = pager.currentPage == page,
                    onLeft = { if (warned) doTrash(m) else pending = m },
                    onRight = { undoLast() }
                )
            }
            // নম্বরে ট্যাপ করলে নির্দিষ্ট ফাইল নম্বরে যাওয়া যাবে
            Text(
                "${pager.currentPage + 1} / ${items.size}  ✎", color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(12.dp)
                    .background(Color(0x66000000), CircleShape)
                    .clickable { showJump = true }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
            // র‍্যাপিড স্ক্রল: চেপে ধরলে সেকেন্ডে ২টা, ডাবল ট্যাপ করে ধরলে সেকেন্ডে ৪টা
            Box(
                Modifier.align(Alignment.BottomEnd).padding(24.dp).size(64.dp)
                    .background(Color(0xCC1E88E5), CircleShape)
                    .pointerInput(Unit) {
                        var lastTap = 0L
                        awaitEachGesture {
                            awaitFirstDown()
                            val t0 = System.currentTimeMillis()
                            rapid = if (t0 - lastTap < 400) 4 else 2
                            waitForUpOrCancellation()
                            val t1 = System.currentTimeMillis()
                            rapid = 0
                            lastTap = if (t1 - t0 < 250) t1 else 0L
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Text(if (rapid == 0) "⏩" else "$rapid/s", color = Color.White, fontSize = 20.sp) }
        }
    }

    if (showJump && items.isNotEmpty()) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showJump = false },
            title = { Text("ফাইল নম্বরে যান (1–${items.size})") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter(Char::isDigit) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.let { n ->
                        scope.launch { pager.scrollToPage((n - 1).coerceIn(0, items.size - 1)) }
                    }
                    showJump = false
                }) { Text("যান") }
            },
            dismissButton = { TextButton(onClick = { showJump = false }) { Text("বাতিল") } }
        )
    }

    pending?.let { m ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("সতর্কতা") },
            text = { Text("বামে সোয়াইপ করলে ছবি/ভিডিও রিসাইকেল বিনে চলে যাবে। ডানে সোয়াইপ করলে আনডু হবে। এরপর আর জিজ্ঞেস করা হবে না।") },
            confirmButton = {
                TextButton(onClick = { warned = true; doTrash(m); pending = null }) { Text("ঠিক আছে, ডিলিট করো") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("বাতিল") } }
        )
    }
}

@Composable
fun Page(m: Media, isCurrent: Boolean, onLeft: () -> Unit, onRight: () -> Unit) {
    var dx by remember { mutableFloatStateOf(0f) }
    var paused by remember { mutableStateOf(false) }
    val left by rememberUpdatedState(onLeft)
    val right by rememberUpdatedState(onRight)

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            translationX = dx
            rotationZ = dx / 40f
            alpha = 1f - (abs(dx) / 1500f).coerceAtMost(0.5f)
        }) {
            if (m.isVideo) {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(m.uri)
                            setOnPreparedListener { it.isLooping = true }
                        }
                    },
                    update = { v -> if (isCurrent && !paused) v.start() else v.pause() },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                AsyncImage(m.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
        // গেসচার লেয়ার: ট্যাপ = ভিডিও পজ/প্লে, বামে সোয়াইপ = ট্র্যাশ, ডানে সোয়াইপ = আনডু
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { paused = !paused } }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            val d = dx; dx = 0f
                            if (d < -SWIPE) left() else if (d > SWIPE) right()
                        },
                        onDragCancel = { dx = 0f }
                    ) { _, delta -> dx += delta }
                }
        )
        if (abs(dx) > SWIPE) {
            Text(
                if (dx < 0) "🗑 ডিলিট" else "↩ আনডু", color = Color.White, fontSize = 24.sp,
                modifier = Modifier.align(Alignment.Center).background(Color(0x99000000)).padding(12.dp)
            )
        }
    }
}
